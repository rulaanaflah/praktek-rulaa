<?php
session_start();

if(!isset($_SESSION['login'])){
    header("location:login.php");
    exit;
}

include 'koneksi.php';

$sql = "SELECT * FROM guru_tki";
$data = mysqli_query($conn, $sql);

if(!$data){
    die("Query Error : " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Biodata Guru TKI</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body style="background-color:#F3F0FF;">

<nav class="navbar navbar-expand-lg navbar-dark"
style="background-color:#8C00FF;">

<div class="container">

    <a class="navbar-brand fw-bold" href="#">
        🧪 TEKNIK KIMIA INDUSTRI
    </a>

    <a href="logout.php"
    class="btn btn-light"
    onclick="return confirm('Yakin ingin logout?')"
    >
        Logout
    </a>

</div>

</nav>

<div class="container mt-5">

    <h2 class="text-center fw-bold"
    style="color:#8C00FF;">
        BIODATA GURU TEKNIK KIMIA INDUSTRI
    </h2>

    <h4 class="text-center mb-4">
        SMKN 2 BALEENDAH
    </h4>

    <p class="text-center"
    style="color:#8C00FF;">
        🧪 Sistem Biodata Guru Teknik Kimia Industri 🧪
    </p>

    <a href="tambah.php"
    class="btn text-white mb-3"
    style="background-color:#8C00FF;">
        + Tambah Data
    </a>

<div class="card shadow-lg p-4 border-0 rounded-4">

<table class="table table-bordered text-center align-middle">

<thead
style="
background: linear-gradient(90deg,#D8B4E2,#8E7AB5);
color:white;
">

<tr>

    <th>No</th>
    <th>Foto</th>
    <th>Nama</th>
    <th>Mata Pelajaran</th>
    <th>Aksi</th>

</tr>

</thead>

<tbody>

<?php
$no = 1;

while($row = mysqli_fetch_assoc($data)){
?>

<tr>

    <td><?= $no++; ?></td>

    <td>

        <a href="detail.php?id=<?= $row['id']; ?>">

    <img
        src="uploads/<?= $row['foto']; ?>"
        width="100"
        class="rounded-circle shadow"
        style="object-fit:cover; height:100px; "
    >

</a>

    </td>

    <td><?= $row['nama']; ?></td>

    <td><?= $row['mapel']; ?></td>

    <td>

        <a
        href="edit.php?id=<?= $row['id']; ?>"
        class="btn btn-warning btn-sm">

            Edit

        </a>

        <a
        href="hapus.php?id=<?= $row['id']; ?>"
        class="btn btn-danger btn-sm"
        onclick="return confirm('Yakin ingin hapus data?')">

            Hapus

        </a>

    </td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</div>

</body>
</html>